#!/bin/bash
user_id=$(mysql -h149.28.149.145 -P3306 -uroot -phyunamae143 opsprime -sN -e "SELECT user_name FROM users WHERE user_name = '$username' AND user_pass = '$password' AND user_server = 'JP1'")
##Check user
[ "$user_id" != '' ] && [ "$user_id" = "$username" ] && echo "user : $username" && echo 'authentication ok.' && exit 0 || echo 'authentication failed.'; exit 1
